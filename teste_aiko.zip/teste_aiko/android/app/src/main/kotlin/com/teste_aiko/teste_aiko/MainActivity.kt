package com.teste_aiko.teste_aiko

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
