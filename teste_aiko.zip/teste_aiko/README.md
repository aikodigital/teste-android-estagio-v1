# teste_aiko

Aplicativo teste para frota de ônibus da cidade de SP.

## Getting Started
As únicas coisas que foram realmente concluídas foram a pesquisa e salvar a localização das paradas em um database, infelizmente.

COMO USAR:
A tela inicial do aplicativo é o mapa, com alguns markers ao redor de SP, que são clicáveis e mostram o nome da parada e o endereço.
As funções recebem mais parâmetros, mas não consegui incluir de um jeito prático, então removi.

Por algum motivo, a função da API de buscar os ônibus pelo código de parada ['cp'] não está funcionando e sempre
retorna um array vazio, então não foi possível incluir isso também, mesmo que com vestígios dentro do códgio.

Ao abrir a tela com o nome da parada ao clicar nos markers, é possível clicar neles, que seria o lugar
onde os ônibus que passariam na parada ficariam, apesar de estar vazio.

O botão de pesquisar é bem simples. Não consegui fazer nenhum tratamento de caso mais especófico
para as respostas da API, então quando é retornado um array vazio, só não aparece nada. Os widgets de quando
tem algum item também são clicáveis. Por agora eles só retornam para a tela principal, mas deveriam
retornar a localização do ônibus no mapa em destaque.

CONCLUSÃO:
Foi uma boa experiência, foi mais difícil do que eu imaginava, ter de se preocupar com layouts e backend.
Infelizmente não foi possível fazer um detalhamento mais a fundo ou limpar as últimas alterações de
código que fiz.

*Uma das coisas que eu gostei foi de ter salvado pelo menos os dados de parada no armazenamento local,
mesmo não tendo feito nenhum método para que o programa fizesse isso de tempos em tempos.

Um abraço!