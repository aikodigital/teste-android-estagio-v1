import 'package:flutter/material.dart';
import 'package:teste_aiko/helper_pages/request_info_classes.dart';

import 'helper_pages/globals.dart' as globals;

List dataFromMarker = [];

void takeData(int fid, String fnome, String fend, double fposy, double fposx) {
  dataFromMarker = [fid, fnome, fend, fposy, fposx];
}

class InfoTela extends StatefulWidget {
  const InfoTela({super.key});

  @override
  State<InfoTela> createState() => _InfoTelaState();
}

class _InfoTelaState extends State<InfoTela> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Color(0XFFBDBDBD)),
        backgroundColor: const Color(0xFF303030),
        centerTitle: true,
        title: const Text(
          "Informações sobre a parada",
          style: TextStyle(color: Color(0XFFBDBDBD)),
        ),
      ),
      body: Column(
        children: [
          globals.makeCard(
              context,
              CardInfo(
                  id: dataFromMarker[0],
                  nome: dataFromMarker[1],
                  nome2: dataFromMarker[2],
                  posy: dataFromMarker[3],
                  posx: dataFromMarker[4],
                  isBus: false)),
          const Text("Próximos ônibus:",
              style: TextStyle(fontSize: 20, color: Color(0xFF303030)))
        ],
      ),
    );
  }
}
