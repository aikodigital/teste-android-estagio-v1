import 'package:flutter/material.dart';
import 'package:teste_aiko/helper_pages/request_info_classes.dart';

import 'helper_pages/globals.dart' as globals;
import 'helper_pages/globals.dart';

class Infobus extends StatefulWidget {
  const Infobus({super.key});

  @override
  State<Infobus> createState() => _InfobusState();
}

class _InfobusState extends State<Infobus> {
  final pesquisaController = TextEditingController();
  List busList = [];

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    pesquisaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: globals.fabFore),
        backgroundColor: globals.fabBack,
        title: TextField(
          controller: pesquisaController,
          style: TextStyle(color: globals.fabFore),
          cursorColor: globals.fabFore,
          autofocus: true,
          decoration: InputDecoration.collapsed(
            hintText: "Pesquise o número ou nome da linha",
            hintStyle: TextStyle(color: globals.fabFore.withOpacity(.4)),
          ),
          onSubmitted: (value) async {
            busList = [];
            var res = await dio.get(
                'Linha/Buscar?termosBusca=${pesquisaController.value.text}');
            for (var item in res.data) {
              busList.add(CardInfo(
                  isBus: true,
                  id: item['cl'],
                  sl: item['sl'],
                  nome: item['tp'],
                  nome2: item['ts']));
            }
            setState(() {});
          },
        ),
      ),
      backgroundColor: const Color(0XFFEAEAEA),
      body: ListView.builder(
          itemCount: busList.length,
          itemBuilder: (BuildContext context, int index) {
            return globals.makeCard(context, busList[index]);
          }),
    );
  }
}
