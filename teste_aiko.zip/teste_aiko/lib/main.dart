import 'package:flutter/material.dart';

import 'helper_pages/fetch_api_data.dart';
import 'helper_pages/globals.dart' as globals;
import 'helper_pages/request_info_classes.dart';
import 'mapa_tela.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  //!!IMPORTANT!! AUTH API
  await initDB();
  globals.parRes = await fetchParada();
  //await fetchBuses();

  runApp(const MapaSPAiko());
}

class MapaSPAiko extends StatelessWidget {
  const MapaSPAiko({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mapa da Frota de Ônibus de SP',
      theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.lightBlue)),
      home: const MapaTela(),
    );
  }
}
