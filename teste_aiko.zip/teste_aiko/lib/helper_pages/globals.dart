library globals;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:teste_aiko/helper_pages/request_info_classes.dart';

//Erros desconhecidos com a API Olho Vivo
var dio =
    Dio(BaseOptions(baseUrl: 'https://aiko-olhovivo-proxy.aikodigital.io/'));

var fabBack = const Color(0xFF303030);
var fabFore = const Color(0XFFBDBDBD);

//!!IMPORTANT!! DOCUMENTAR
List? parRes;
List? busRes;
List passHere = [];

late Future<BusInfo> busFuture;

Widget makeCard(context, CardInfo card) {
  if (card.isBus == false) {
    return Container(
      margin: const EdgeInsets.all(8),
      height: 100,
      child: ElevatedButton(
          onPressed: () async {
            var res = await dio
                .get('/Parada/BuscarParadasPorLinha?codigoLinha=${card.id}');

            print(card.id);

            passHere = [];
          },
          style: ElevatedButton.styleFrom(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15))),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '${card.nome}',
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: Color(0xFF303030),
                    fontSize: 20,
                    fontWeight: FontWeight.w800),
              ),
              SizedBox(
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.location_on_rounded,
                        color: Color(0xFF303030),
                        size: 35,
                      ),
                      SizedBox(
                        width: 330,
                        child: Text(
                          '${card.nome2}',
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              color: Color(0xFF303030), fontSize: 16),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          )),
    );
  } else {
    //CARD ONIBUS
    return ListTile(
      title: ElevatedButton(
        style: ElevatedButton.styleFrom(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15))),
        child: SizedBox(
          height: 100,
          width: 330,
          child: Row(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Text(
                    "Código Linha",
                    style: TextStyle(color: Color(0xFF303030), fontSize: 14),
                  ),
                  Text("${card.id}",
                      style: TextStyle(
                          color: fabBack,
                          fontWeight: FontWeight.w800,
                          fontSize: 20)),
                  Builder(builder: (context) {
                    if (card.sl == 1) {
                      return const Text(
                        "Ida",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF303030)),
                      );
                    }
                    return const Text(
                      "Volta !!",
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF303030)),
                    );
                  }),
                ],
              ),
              const VerticalDivider(),
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(
                      width: 200,
                      child: Text("De ${card.nome}",
                          style: TextStyle(
                              color: fabBack,
                              fontWeight: FontWeight.w500,
                              fontSize: 18),
                          overflow: TextOverflow.ellipsis)),
                  SizedBox(
                      width: 200,
                      child: Text("Para ${card.nome2}",
                          style: TextStyle(
                              color: fabBack,
                              fontWeight: FontWeight.w500,
                              fontSize: 18),
                          overflow: TextOverflow.ellipsis))
                ],
              )
            ],
          ),
        ),
        onPressed: () {
          Navigator.pop(context);
        },
      ),
    );
  }
}
