import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import 'globals.dart';

class Linhas {
  int id; // cl - Código identificador da linha
  //bool circular; // lc - Indica se uma linha opera no modo circular
  //String let1; // lt - Informa a primeira parte do letreiro numérico da linha
  //int let2 = 10; // Segunda parte lereiro (BASE 10) (ATENDIMENTO 21, 23, 32, 41)
  //int snt = 1; // Sentido da linha. 1: TP->TS, 2: TS->TP
  //String sentidots; // tp - Letreiro indo no sentido TP->TS
  //String sentidotp; // ts - Letreiro indo no sentido TS->TP

  double px;
  double py;

  Linhas(
      {required this.id,
      //required this.circular,
      //required this.let1,
      //required this.sentidots,
      //required this.sentidotp,
      required this.px,
      required this.py});
}

class Paradas {
  int id; // cp - Código identificador da parada
  String nome; // np - Nome da parada
  String end; // ed - Endereço de localização da parada
  double posy; // py - Informação de latitude da localização da parada
  double posx; // px - Informação de longitude da localização da parada

  Paradas(
      {required this.id,
      required this.nome,
      required this.end,
      required this.posy,
      required this.posx});
}

class Corredores {
  int id; // cc - Código identificador da corredor.
  String nome; // nc - Nome do corredor

  Corredores({required this.id, required this.nome});
}

class Empresas {
  int id; // c - Código de referência da empresa
  String nome; // n - Nome da empresa
  int op; // a - Código da área de operação

  Empresas({required this.id, required this.nome, required this.op});
}

class CardInfo {
  int? id;
  int? sl;
  String? nome;
  String? nome2;
  String? prev;
  bool isBus;

  double? posy;
  double? posx;

  CardInfo(
      {this.id,
      this.sl,
      this.nome,
      this.nome2,
      this.prev,
      this.posy,
      this.posx,
      required this.isBus});
}

class BusInfo {
  int p;
  String t;

  BusInfo({required this.p, required this.t});
}

//!!IMPORTANT!! RECUPERAR DADOS DO DB
Future fetchParada() async {
  final db = await openDatabase(join(await getDatabasesPath(), 'frota_sp.db'));
  final List paradasMap = await db.query('paradas');

  final List parList = paradasMap
      .map((parItem) => Paradas(
          id: parItem['id'],
          nome: parItem['nome'],
          end: parItem['end'],
          posy: parItem['posy'],
          posx: parItem['posx']))
      .toList();

  return parList;
}

/*Future fetchBuses() async {
  var res = await dio.get('Posicao');
  print(res.data['l'][0]['vs']['py']);

  for (var item in res.data) {
    busRes?.add(Linhas(
        id: item['l'][0]['cl'],
        px: item['l'][0]['vs'][0]['px'],
        py: item['l'][0]['vs'][0]['py']));
  }
}*/