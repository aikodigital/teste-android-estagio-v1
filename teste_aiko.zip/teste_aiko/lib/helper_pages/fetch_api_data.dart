// ignore_for_file: unused_import

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:teste_aiko/helper_pages/request_info_classes.dart';
import 'package:teste_aiko/main.dart';

import 'globals.dart';

Future<List> fetchClasses() async {
  var resPar =
      await dio.get('Parada/Buscar?termosBusca='); //Solicitar dados das Paradas
  var resCor = await dio.get('Corredor'); //Solicitar dados dos Corredores
  var resEmp = await dio.get('Empresa'); //Solicitar dados das Empresas

  if (resPar.statusCode != 200) {
    throw Exception("Erro ao buscar dados de Parada na API");
  }
  if (resCor.statusCode != 200) {
    throw Exception("Erro ao buscar dados de Corredor na API");
  }
  if (resEmp.statusCode != 200) {
    throw Exception("Erro ao buscar dados de Empresa na API");
  }
  return resPar.data;
  //res.add(resCor.data);
  //res.add(resEmp.data);
}

//!!IMPORTANT!! DOCUMENTAR
Future<void> insertDB(List<dynamic> list, int n, Database db) async {
  switch (n) {
    case 0:
      for (Map element in list) {
        await db.insert(
          'paradas',
          {
            'id': element['cp'],
            'nome': element['np'],
            'end': element['ed'],
            'posy': element['py'],
            'posx': element['px']
          },
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      break;
    case 1:
      for (Map element in list) {
        await db.insert(
          'corredores',
          {'id': element['cc'], 'nome': element['cn']},
          conflictAlgorithm: ConflictAlgorithm.replace,
        );
      }
      break;
  }
}

//!!IMPORTANT!! INICIALIZAR DB
Future<void> initDB() async {
  final exec =
      await databaseExists(join(await getDatabasesPath(), 'frota_sp.db'));
  if (!exec) {
    //!!IMPORTANT!! DOCUMENTAR
    final frotaSp = openDatabase(join(await getDatabasesPath(), 'frota_sp.db'),
        onCreate: (db, version) async {
      db.execute(
          'CREATE TABLE linhas(id INTEGER PRIMARY KEY, circular INTEGER, let1 TEXT, let2 INTEGER, snt INTEGER, sentidots TEXT, sentidotp TEXT)');
      db.execute(
          'CREATE TABLE paradas(id INTEGER PRIMARY KEY, nome TEXT, end TEXT, posy REAL, posx REAL)');
      db.execute('CREATE TABLE corredores(id INTEGER PRIMARY KEY, nome TEXT)');
      db.execute(
          'CREATE TABLE empresas(id INTEGER PRIMARY KEY, nome TEXT, op INTEGER)');
    }, version: 1);

    final db = await frotaSp;
    var data = await fetchClasses();
    insertDB(data, 0, db); //Parada
  }
}
