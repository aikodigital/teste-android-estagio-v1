import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:teste_aiko/info_onibus.dart';

import 'helper_pages/globals.dart' as globals;
import 'info_parada.dart';

class MapaTela extends StatefulWidget {
  const MapaTela({super.key});

  @override
  State<MapaTela> createState() => _MapaTelaState();
}

class _MapaTelaState extends State<MapaTela> {
  final template = "http://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png";
  final LatLng _initPos = const LatLng(-23.555836067258564, -46.64003606659164);

  @override
  Widget build(BuildContext context) {
    //!!IMPORTANT!! DOCUMENTAR
    List<Marker> markers = List.generate(
        globals.parRes?.length as int,
        (int index) => Marker(
            point: LatLng(
                globals.parRes?[index].posy, globals.parRes?[index].posx),
            child: IconButton(
              onPressed: () {
                print(globals.parRes?[index].id);
                takeData(
                    globals.parRes?[index].id,
                    globals.parRes?[index].nome,
                    globals.parRes?[index].end,
                    globals.parRes?[index].posy,
                    globals.parRes?[index].posx);
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return const InfoTela();
                }));
              },
              icon: const Icon(Icons.location_on, color: Color(0XFF303030)),
            )),
        growable: false);

    /*List<Marker> buses = List.generate(
      globals.busRes?.length as int,
        (int index) => Marker(
          point: LatLng(globals.busRes?[index].py, globals.busRes?[index].px),
          child: Icon(Icons.contact_mail_sharp),
        ),
      growable: false
    );*/

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: FlutterMap(
        options: MapOptions(
            initialCenter: _initPos, initialZoom: 17, maxZoom: 19, minZoom: 15),
        children: [
          TileLayer(
            urlTemplate: template,
            userAgentPackageName: 'com.example.app', //TODO MUDAR PACKAGE
          ),
          MarkerLayer(
            markers: markers,
          ),
          //MarkerLayer(markers: buses),
        ],
      ),
      floatingActionButton: Container(
        padding: const EdgeInsets.only(bottom: 65, right: 25),
        child: SizedBox(
          height: 70,
          child: FloatingActionButton(
            foregroundColor: globals.fabFore,
            backgroundColor: globals.fabBack,
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => const Infobus()));
            },
            tooltip: 'Pesquisar',
            heroTag: 'Pesquisar',
            child: const Icon(Icons.search, color: Color(0XFFBDBDBD)),
          ),
        ),
      ),
    );
  }
}
