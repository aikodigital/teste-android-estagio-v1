package com.example.testeandroid;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.SearchView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity implements OnMapReadyCallback{

    private static final String API_KEY = "5e6fc2d36f015718ffa6dbf9ebd3be3b891a76eb575edfbf7681be4985f3df13";
    private MapView mapView;
    private GoogleMap googleMap;
    private RecyclerView recyclerView;
    private BusLineAdapter adapter;
    private List<Linha> busLineList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mapView = findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        SearchView searchView = findViewById(R.id.searchView);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        busLineList = new ArrayList<>();
        adapter = new BusLineAdapter(busLineList);
        recyclerView.setAdapter(adapter);

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                fetchBusLine(query);
                return false;
            }

            private void fetchBusLine(String query) {
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        authenticateAndFetchData();
    }

    private void authenticateAndFetchData() {
        OlhovivoApi.authenticate();
    }



    private void fetchBusPositions() {
        OlhovivoApi.getVeiculosPosicao(new okhttp3.Callback() {
            @Override
            public void onFailure(okhttp3.Call call, java.io.IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(okhttp3.Call call, okhttp3.Response response) throws java.io.IOException {
                if (response.isSuccessful()) {
                    // Parse response and update MapView
                }
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        // Configurar mapa
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}

