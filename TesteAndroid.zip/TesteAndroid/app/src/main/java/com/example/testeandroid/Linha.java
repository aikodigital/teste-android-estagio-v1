package com.example.testeandroid;

public class Linha {
    private String name;

    public Linha(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
