package com.example.testeandroid;

import java.util.List;

import okhttp3.Callback;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public interface OlhovivoApi {
        static String authenticate() {
                return null;
        }


    @GET("Posicao")
    static Call<PosicaoResponse> getVeiculosPosicao(Callback callback) {
        return null;
    }

    @GET("Linha/Buscar")
        Call<List<Linha>> getLinhas(@Query("termosBusca") String termosBusca);

        @GET("Parada/Buscar")
        Call<List<Parada>> getParadas(@Query("termosBusca") String termosBusca);

        @GET("Previsao/Parada")
        Call<Previsao> getPrevisao(@Query("codigoParada") String codigoParada);
        public static void getBusLines(String query, Callback callback) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://api.olhovivo.sptrans.com.br/v2.1/Linha/Buscar?termosBusca=" + query)
                        .addHeader("Cookie", OlhovivoApi.authenticate()).build();


                Call call = (Call) client.newCall(request);
                call.enqueue((retrofit2.Callback) callback);
        }

        static void build() {
        }


        public static void getBusPositions(Callback callback) {
                OkHttpClient client = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://api.olhovivo.sptrans.com.br/v2.1/Posicao")
                        .addHeader("Cookie", OlhovivoApi.authenticate())
                        .build();

                Call call = (Call) client.newCall(request);
                call.enqueue((retrofit2.Callback) callback);
        }
    }

