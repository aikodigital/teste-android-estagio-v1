package com.example.testeandroid;

public class Previsao {
}
