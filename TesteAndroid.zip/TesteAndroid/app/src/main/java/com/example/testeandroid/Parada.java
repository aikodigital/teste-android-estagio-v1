package com.example.testeandroid;

public class Parada {
}
