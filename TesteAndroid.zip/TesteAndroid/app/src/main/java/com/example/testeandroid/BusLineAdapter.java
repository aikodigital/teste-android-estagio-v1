package com.example.testeandroid;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class BusLineAdapter extends RecyclerView.Adapter {
    private List<Linha> busLineList;

    public BusLineAdapter(List<Linha> busLineList) {
        this.busLineList = busLineList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bus_line, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Linha busLine = busLineList.get(position);
        holder.busLineName.setText(busLine.getName());
    }

    @Override
    public int getItemCount() {
        return busLineList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView busLineName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            busLineName = itemView.findViewById(R.id.busLineName);
        }
    }
}
