# AAB to APK Converter
![aab2apk](https://user-images.githubusercontent.com/101784407/158752274-d32f5772-1a66-4a6e-a752-b10e9ccadb68.png)

It is first tool that I have developed and shared with the world. Hope it is useful. I am open to suggestions and bug reports.

## Scripts
- **bundletool_bridge.py**: Backend script which handles tasks that are to be performed.
- **BundleToolGUI.py**: UI part is handled by this script which uses tkinter for GUI.

## How to build
- Use pyinstaller to create executable
- Keystore folder and bundletool jar is to be copied to distribution folder
